# ADR Index

- [ADR-0001: GPU World Generator Package Scope](./adr-0001-package-scope.md)
- [ADR-0002: Tiled World Generation, LOD, and Stitching](./adr-0002-world-tiling-lod-stitching.md)
- [ADR-0003: Terrain Generation Style Mixing (Shader-Based)](./adr-0003-terrain-generation-style-mixing.md)
- [ADR-0004: Worker DAG Manifests for Chunk and Voxel Generation](./adr-0004-worker-dag-manifests-for-chunk-and-voxel-generation.md)
- [ADR-0005: Render Representation Tiers and Proxy Outputs](./adr-0005-render-representation-tiers-and-proxy-outputs.md)
